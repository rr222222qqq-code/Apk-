package com.example.dragontigerscanner

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val pickImage = 101
    private lateinit var dragonSpinner: Spinner
    private lateinit var tigerSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var historyView: TextView
    private val ranks = listOf("?", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")
    private var lastOcr = ""
    private val prefs by lazy { getSharedPreferences("history", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 20) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(-1, -1))
        setContentView(root)

        content.addView(text("Dragon vs Tiger Scanner", 25, true))
        content.addView(text("Spin Crush के स्क्रीनशॉट से खुले कार्ड पढ़ने और राउंड हिस्ट्री रखने का शुरुआती टूल।", 15, false))
        val pick = Button(this).apply { text = "1. गेम का स्क्रीनशॉट चुनें"; setOnClickListener { openPicker() } }
        content.addView(pick)
        status = text("पहले स्क्रीनशॉट चुनें। OCR की पहचान गलत हो सकती है।", 15, false)
        content.addView(status)
        content.addView(text("Dragon का कार्ड (जाँच/सुधारें)", 17, true))
        dragonSpinner = Spinner(this).also { it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ranks) }
        content.addView(dragonSpinner)
        content.addView(text("Tiger का कार्ड (जाँच/सुधारें)", 17, true))
        tigerSpinner = Spinner(this).also { it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ranks) }
        content.addView(tigerSpinner)
        content.addView(Button(this).apply { text = "2. रिजल्ट निकालें और हिस्ट्री सेव करें"; setOnClickListener { saveRound() } })
        content.addView(Button(this).apply { text = "हिस्ट्री रीफ्रेश करें"; setOnClickListener { showHistory() } })
        content.addView(Button(this).apply { text = "हिस्ट्री मिटाएँ"; setOnClickListener { prefs.edit().remove("rounds").apply(); showHistory() } })
        content.addView(text("राउंड हिस्ट्री", 20, true))
        historyView = text("अभी कोई राउंड सेव नहीं है।", 14, false)
        content.addView(historyView)
        showHistory()
    }

    private fun text(s: String, size: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(0xff17202a.toInt());
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, 10, 0, 10)
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        startActivityForResult(Intent.createChooser(intent, "गेम स्क्रीनशॉट चुनें"), pickImage)
    }

    @Deprecated("Deprecated Android callback kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickImage || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        status.text = "स्क्रीनशॉट पढ़ रहा है…"
        try {
            val bitmap = loadBitmap(uri)
            runOcr(bitmap)
        } catch (e: Exception) { status.text = "तस्वीर नहीं खुली: ${e.message}" }
    }

    private fun loadBitmap(uri: Uri): Bitmap = if (Build.VERSION.SDK_INT >= 28) {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { decoder, _, _ -> decoder.isMutableRequired = false }
    } else {
        @Suppress("DEPRECATION")
        MediaStore.Images.Media.getBitmap(contentResolver, uri)
    }

    private fun runOcr(bitmap: Bitmap) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                lastOcr = result.text
                val tokens = Regex("(?i)(10|[2-9]|A|K|Q|J)").findAll(result.text).map { it.value.uppercase(Locale.ROOT) }.toList()
                val guesses = tokens.filter { it in ranks }
                val d = guesses.getOrNull(0) ?: "?"
                val t = guesses.getOrNull(1) ?: "?"
                dragonSpinner.setSelection(ranks.indexOf(d).coerceAtLeast(0))
                tigerSpinner.setSelection(ranks.indexOf(t).coerceAtLeast(0))
                status.text = "OCR पूरा हुआ। अनुमान: Dragon=$d, Tiger=$t. नीचे कार्ड खुद जाँचकर सही करें।\nपहचाना गया टेक्स्ट: ${result.text.take(350)}"
            }
            .addOnFailureListener { status.text = "OCR नहीं हो पाया: ${it.message}" }
    }

    private fun value(rank: String): Int = when (rank) { "A" -> 1; "J" -> 11; "Q" -> 12; "K" -> 13; else -> rank.toIntOrNull() ?: 0 }

    private fun saveRound() {
        val d = dragonSpinner.selectedItem.toString(); val t = tigerSpinner.selectedItem.toString()
        if (d == "?" || t == "?") { status.text = "दोनों कार्ड चुनें या OCR पहचान को सुधारें, फिर सेव करें।"; return }
        val outcome = when { value(d) > value(t) -> "Dragon"; value(t) > value(d) -> "Tiger"; else -> "Tie" }
        val arr = try { JSONArray(prefs.getString("rounds", "[]")) } catch (_: Exception) { JSONArray() }
        val item = JSONObject().put("time", SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date()))
            .put("dragon", d).put("tiger", t).put("result", outcome)
        arr.put(item)
        prefs.edit().putString("rounds", arr.toString()).apply()
        status.text = "सेव हुआ: Dragon $d बनाम Tiger $t → $outcome"
        showHistory()
    }

    private fun showHistory() {
        val arr = try { JSONArray(prefs.getString("rounds", "[]")) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) { historyView.text = "अभी कोई राउंड सेव नहीं है।"; return }
        val lines = mutableListOf<String>()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            lines.add("${o.optString("time")}\nDragon ${o.optString("dragon")} | Tiger ${o.optString("tiger")} → ${o.optString("result")}")
        }
        val counts = mutableMapOf("Dragon" to 0, "Tiger" to 0, "Tie" to 0)
        for (i in 0 until arr.length()) {
            val result = arr.optJSONObject(i)?.optString("result") ?: continue
            if (counts.containsKey(result)) counts[result] = (counts[result] ?: 0) + 1
        }
        historyView.text = "कुल ${arr.length()} राउंड | Dragon ${counts["Dragon"]} · Tiger ${counts["Tiger"]} · Tie ${counts["Tie"]}\n\n" + lines.joinToString("\n\n")
    }
}
