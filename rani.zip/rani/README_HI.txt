Dragon vs Tiger Scanner — शुरुआती Android प्रोजेक्ट

यह संस्करण चुने हुए स्क्रीनशॉट पर ML Kit OCR चलाता है, OCR से मिले पहले दो कार्ड-जैसे टेक्स्ट को सुझाव की तरह भरता है, और यूज़र द्वारा जाँचे/सुधारे गए कार्ड का नतीजा लोकल हिस्ट्री में सेव करता है। यह अभी गेम के ऊपर लाइव फ्लोटिंग बटन या लगातार ऑटो-स्कैन नहीं करता। कार्ड आर्टवर्क OCR से हमेशा सही नहीं पढ़ा जाएगा; हर राउंड सेव करने से पहले कार्ड जाँचें। छिपे हुए कार्ड या अगला राउंड अनुमान नहीं करता।

फोन से APK बनाने के लिए:
1. GitHub में नया repository बनाएँ, उदाहरण: DragonTigerScanner.
2. इस ZIP की सभी फाइलें repository में upload करें; .github/workflows/build-apk.yml भी शामिल हो।
3. Commit changes करें।
4. Repository में Actions खोलें। Build Android APK workflow चुनें। Run workflow दबाएँ।
5. Build पूरा होने पर DragonTigerScanner-debug-apk artifact डाउनलोड करें। ZIP को extract करें; app-debug.apk मिलेगी।
6. APK फोन में खोलें और install करें। Android पूछे तो इस स्रोत से install की अनुमति दें।

ध्यान: APK बनाने के लिए GitHub Actions इंटरनेट और GitHub account की जरूरत होगी। यह शुरुआती prototype है, उत्पादन-स्तर का कार्ड विज़न मॉडल नहीं।
